import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TestMath {

    @Test
    void MultiplyTest(){
        int result = Main.Multiply(5,6);
        assertEquals(30,result);
    }

    @Test
    void PrimeTest(){
        boolean result = Main.PrimeOrNo(5);
        assertEquals(true,result);
    }
}

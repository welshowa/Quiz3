public class Main {
    public static void main(String[] args) {

        System.out.println("Hello, World!");
    }


    public static int Multiply(int x, int y) {
        return x * y; //supposed to be multiply
    }

    public static boolean PrimeOrNo(int x) {

        if (x < 2) {
            return false; //supposed to be false
        }


        for (int i = 2; i * i <= x; i++) {
            if (x % i == 0) {
                return false; //supposed to be false
            }
        }


        return true; //supposed to be true
    }
}